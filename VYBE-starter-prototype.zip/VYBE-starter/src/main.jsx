import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { Heart, Flame, MessageCircle, UserRound, Compass, Sparkles, SlidersHorizontal, Send, X, Check, ShieldCheck, Gift } from "lucide-react";
import "./style.css";

const people = [
  { name: "Amani", age: 25, city: "Nairobi", about: "Good conversations, spontaneous adventures and genuine connection.", tags: ["Music", "Travel", "Coffee"], color: "rose", initials: "A" },
  { name: "Nia", age: 23, city: "Nakuru", about: "Here for laughter, kindness and seeing where chemistry leads.", tags: ["Movies", "Food", "Art"], color: "violet", initials: "N" },
  { name: "Zuri", age: 27, city: "Mombasa", about: "A little romance, a little adventure, and lots of good energy.", tags: ["Beach", "Books", "Dance"], color: "wine", initials: "Z" }
];

const starters = [
  "What's something that instantly makes you smile?",
  "Are you more into spontaneous dates or carefully planned ones?",
  "What's your idea of a perfect evening?",
  "What's one quality you find irresistible?",
  "Should we start with a compliment or a playful question?"
];

function App() {
  const [tab, setTab] = useState("Discover");
  const [index, setIndex] = useState(0);
  const [liked, setLiked] = useState([]);
  const [matches, setMatches] = useState([]);
  const [messages, setMessages] = useState([{ from: "them", text: "Hey! Glad we matched. 😊" }]);
  const [draft, setDraft] = useState("");
  const [mood, setMood] = useState("Romantic");
  const [showPrompts, setShowPrompts] = useState(false);
  const [profile, setProfile] = useState({ name: "Your profile", intention: "Open to connection" });
  const person = people[index % people.length];

  function next(like) {
    if (like) {
      setLiked([...liked, person.name]);
      setMatches([...matches, person.name]);
    }
    setIndex(index + 1);
  }
  function sendMessage(text = draft) {
    if (!text.trim()) return;
    setMessages([...messages, { from: "me", text: text.trim() }]);
    setDraft("");
    setShowPrompts(false);
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><span className="brand-mark">♥</span><span>VYBE</span></div>
      <span className="status-pill"><i/> Your next connection</span>
      <button className="icon-btn" aria-label="Settings"><SlidersHorizontal size={19}/></button>
    </header>

    <main>
      {tab === "Discover" && <section className="page">
        <div className="eyebrow">YOUR PEOPLE, YOUR PACE</div>
        <h1>Find your <em>VYBE.</em></h1>
        <p className="sub">Meet people who match your energy.</p>
        <div className={`person-card ${person.color}`}>
          <div className="photo-placeholder"><div className="orb">{person.initials}</div><span className="photo-note">PROFILE PREVIEW</span></div>
          <div className="person-info">
            <div className="person-title"><div><h2>{person.name}, {person.age}</h2><p>⌖ {person.city} · Sample profile</p></div><span className="verified"><ShieldCheck size={15}/> Demo</span></div>
            <p className="bio">{person.about}</p>
            <div className="tags">{person.tags.map(t => <span key={t}>{t}</span>)}</div>
          </div>
        </div>
        <div className="actions">
          <button className="round-btn pass" onClick={() => next(false)} aria-label="Pass"><X/></button>
          <button className="round-btn like" onClick={() => next(true)} aria-label="Like"><Heart fill="currentColor"/></button>
          <button className="round-btn spark" onClick={() => {setTab("Flirt");setMood("Playful")}} aria-label="Flirt"><Flame/></button>
        </div>
        <p className="hint">Sample profiles only · Likes: {liked.length} · Matches in this demo: {matches.length}</p>
      </section>}

      {tab === "Likes" && <section className="page">
        <div className="eyebrow">MUTUAL INTEREST</div><h1>Your <em>likes.</em></h1>
        <p className="sub">People you've liked in this prototype.</p>
        {liked.length ? <div className="list">{liked.map(n => <div className="list-row" key={n}><div className="avatar">{n[0]}</div><div><b>{n}</b><small>You've shown interest</small></div><Heart color="#fb7185" fill="#fb7185"/></div>)}</div> : <div className="empty"><Heart/><b>Your story starts with a like.</b><span>Explore profiles and show someone you're interested.</span></div>}
      </section>}

      {tab === "Messages" && <section className="page chat-page">
        <div className="eyebrow">PRIVATE CONVERSATIONS</div><h1>Say <em>hello.</em></h1>
        <div className="chat-head"><div className="avatar">A</div><div><b>Amani · Demo chat</b><small>Sample conversation</small></div><span className="online">● Demo</span></div>
        <div className="chat-window">{messages.map((m,i)=><div key={i} className={`bubble ${m.from}`}>{m.text}</div>)}</div>
        <div className="mood-row"><span>Conversation mood</span><select value={mood} onChange={e=>setMood(e.target.value)}><option>Romantic</option><option>Playful</option><option>Flirty</option><option>Spicy (adults only)</option></select></div>
        <button className="prompt-btn" onClick={()=>setShowPrompts(!showPrompts)}><Sparkles size={16}/> Conversation starters</button>
        {showPrompts && <div className="prompt-list">{starters.map(s=><button key={s} onClick={()=>sendMessage(s)}>{s}</button>)}</div>}
        <form className="composer" onSubmit={e=>{e.preventDefault();sendMessage()}}><input value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Write a message…" /><button aria-label="Send"><Send size={18}/></button></form>
        <p className="hint">Demo only: messages are not sent or stored online.</p>
      </section>}

      {tab === "Flirt" && <section className="page">
        <div className="eyebrow">MAKE THE FIRST MOVE</div><h1>Set the <em>mood.</em></h1>
        <p className="sub">Choose a tone and find a natural way to start.</p>
        <div className="mood-grid">{["Romantic","Playful","Flirty","Spicy (18+)"].map((m,i)=><button key={m} className={mood===m?"mood-card selected":"mood-card"} onClick={()=>setMood(m)}><span>{["♡","✦","😘","🔥"][i]}</span><b>{m}</b></button>)}</div>
        <div className="prompt-feature"><Sparkles color="#fda4af"/><span className="eyebrow">A MESSAGE FOR THIS MOOD</span><h2>{mood==="Romantic"?"I want to be the reason you smile at your phone tonight.":mood==="Playful"?"Important question: are you always this charming?":mood==="Flirty"?"I was going to play it cool, but you make that difficult.":"Only if we're both comfortable: what's your idea of a perfect intimate evening?"}</h2><button className="primary-btn" onClick={()=>{setTab("Messages");setDraft(mood==="Romantic"?"I want to be the reason you smile at your phone tonight.":mood==="Playful"?"Important question: are you always this charming?":mood==="Flirty"?"I was going to play it cool, but you make that difficult.":"Only if we're both comfortable: what's your idea of a perfect intimate evening?")}}>Use in chat <Send size={16}/></button></div>
        <p className="hint">Adult-oriented prompts must be limited to verified adults who have opted in. This prototype does not verify age or deliver messages.</p>
      </section>}

      {tab === "Profile" && <section className="page">
        <div className="eyebrow">YOUR SPACE</div><h1>About <em>you.</em></h1>
        <div className="profile-card"><div className="profile-avatar">V</div><h2>{profile.name}</h2><span className="sub">{profile.intention}</span><span className="demo-label">LOCAL DEMO PROFILE</span></div>
        <label className="field-label">Display name<input value={profile.name} onChange={e=>setProfile({...profile,name:e.target.value})}/></label>
        <label className="field-label">Relationship intention<select value={profile.intention} onChange={e=>setProfile({...profile,intention:e.target.value})}><option>Open to connection</option><option>Serious relationship</option><option>Casual dating</option><option>Friendship first</option></select></label>
        <div className="safety-note"><ShieldCheck/><div><b>Your safety matters</b><p>Before launch, VYBE will include age checks, privacy controls, blocking and reporting.</p></div></div>
      </section>}
    </main>

    <nav className="bottom-nav">
      {[["Discover",Compass],["Likes",Heart],["Messages",MessageCircle],["Flirt",Flame],["Profile",UserRound]].map(([label,Icon])=><button key={label} className={tab===label?"nav-item active":"nav-item"} onClick={()=>setTab(label)}><Icon size={20}/><span>{label}</span></button>)}
    </nav>
    <footer>VYBE · CONCEPT PROTOTYPE · NOT YET CONNECTED TO A SERVER</footer>
  </div>;
}

createRoot(document.getElementById("root")).render(<App/>);